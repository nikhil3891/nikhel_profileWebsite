# Nikhel Tiwariy — Portfolio Website

Built with **Next.js 14**, **Tailwind CSS**, **MongoDB**, and deployed on **Vercel**.

---

## 🗂 Project Structure

```
nikhel-portfolio/
├── app/
│   ├── api/contact/route.ts   ← Contact form API (saves to MongoDB + sends email)
│   ├── components/
│   │   ├── Navbar.tsx
│   │   ├── Hero.tsx
│   │   ├── About.tsx
│   │   ├── Experience.tsx
│   │   ├── Projects.tsx
│   │   ├── Skills.tsx
│   │   ├── Contact.tsx
│   │   └── Footer.tsx
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── lib/
│   ├── mongodb.ts             ← DB connection (cached for serverless)
│   └── models/Contact.ts     ← Mongoose schema
├── .env.local.example         ← Copy this to .env.local
├── .gitignore
├── next.config.js
├── tailwind.config.ts
└── package.json
```

---

## 🚀 Deployment Guide (Step by Step)

### Step 1 — Set up environment variables

Copy `.env.local.example` to `.env.local` and fill in your values:

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:
```
MONGODB_URI=mongodb+srv://nekhiltiwariy_db_user:YOUR_NEW_PASSWORD@cluster0.ssvgsif.mongodb.net/nikhel_portfolio?appName=Cluster0
EMAIL_USER=8.nikhil3@gmail.com
EMAIL_PASS=your_gmail_app_password
EMAIL_TO=8.nikhil3@gmail.com
```

> ⚠️ **IMPORTANT:** Change your MongoDB password first at https://cloud.mongodb.com
> The old password was exposed. Go to: Database Access → Edit User → Change Password

### Step 2 — Get Gmail App Password (for email notifications)

1. Go to https://myaccount.google.com
2. Security → 2-Step Verification → turn it ON
3. Security → App Passwords
4. Select app: "Mail", device: "Other" → name it "Portfolio"
5. Copy the 16-char password → paste into `EMAIL_PASS` in `.env.local`

### Step 3 — Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

### Step 4 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: portfolio website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/nikhel-portfolio.git
git push -u origin main
```

> ⚠️ NEVER commit `.env.local` — it's in `.gitignore` already ✅

### Step 5 — Deploy on Vercel

1. Go to https://vercel.com → Sign in with GitHub
2. Click **"New Project"** → Import your `nikhel-portfolio` repo
3. Framework: **Next.js** (auto-detected)
4. Click **"Environment Variables"** and add:

| Key | Value |
|-----|-------|
| `MONGODB_URI` | your full MongoDB connection string |
| `EMAIL_USER` | 8.nikhil3@gmail.com |
| `EMAIL_PASS` | your Gmail app password |
| `EMAIL_TO` | 8.nikhil3@gmail.com |

5. Click **Deploy** 🎉

### Step 6 — Custom domain (optional)

In Vercel → Your Project → Settings → Domains → Add your domain.

---

## 🗄 MongoDB — Viewing Contact Form Submissions

All form submissions are saved in your `nikhel_portfolio` database, `contacts` collection.

**To view them:**
1. Go to https://cloud.mongodb.com
2. Browse Collections → `nikhel_portfolio` → `contacts`

Each document has:
```json
{
  "name": "John Smith",
  "email": "john@company.com",
  "phone": "+91...",
  "subject": "Node.js Developer Role",
  "message": "We have an opening...",
  "type": "employer",        // employer | freelance | other
  "status": "new",           // new | read | replied
  "createdAt": "2026-01-01"
}
```

---

## 🔮 Future Roadmap

- **Admin Dashboard** — `/admin` page to view, filter, and reply to leads
- **Sub-admin roles** — Multi-user admin with permissions
- **Company website** — Separate React/Next.js site for your company
- **CRM features** — Track leads, set follow-up reminders, export to CSV
- **Blog section** — Write about your tech learnings to boost SEO

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React 18, Tailwind CSS |
| Fonts | Syne (headings), DM Sans (body), JetBrains Mono (code) |
| Backend | Next.js API Routes (serverless) |
| Database | MongoDB Atlas via Mongoose |
| Email | Nodemailer + Gmail SMTP |
| Hosting | Vercel |
| Animations | CSS + IntersectionObserver |
